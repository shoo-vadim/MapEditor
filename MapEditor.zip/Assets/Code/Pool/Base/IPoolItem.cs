﻿namespace Code
{
    public interface IPoolItem
    {
        void Setup();
        void Drop();
    }
}