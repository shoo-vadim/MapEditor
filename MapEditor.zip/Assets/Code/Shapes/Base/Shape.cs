﻿namespace Code
{
    public enum Shape
    {
        Sphere,
        Cube,
        Cylinder
    }
}