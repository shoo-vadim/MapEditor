﻿namespace Code
{
    public class CubeShape : MonoShape
    {
        
    }
}