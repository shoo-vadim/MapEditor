﻿namespace Code
{
    public class SphereShape : MonoShape
    {
        
    }
}