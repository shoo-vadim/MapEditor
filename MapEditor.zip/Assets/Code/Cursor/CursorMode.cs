﻿namespace Code
{
    public enum CursorMode
    {
        Off,
        Selection,
        Sphere,
        Cube,
        Cylinder
    }
}