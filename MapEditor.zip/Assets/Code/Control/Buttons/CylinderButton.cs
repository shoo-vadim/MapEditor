﻿namespace Code
{
    public class CylinderButton : BaseButton
    {
        
    }
}