﻿namespace Code
{
    public class SphereButton : BaseButton
    {
        
    }
}