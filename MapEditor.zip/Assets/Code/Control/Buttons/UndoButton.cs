﻿namespace Code
{
    public class UndoButton : BaseButton
    {
        
    }
}