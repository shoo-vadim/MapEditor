﻿namespace Code
{
    public class CubeButton : BaseButton
    {
        
    }
}