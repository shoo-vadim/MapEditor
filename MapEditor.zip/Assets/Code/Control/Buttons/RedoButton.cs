﻿namespace Code
{
    public class RedoButton : BaseButton
    {
        
    }
}