﻿namespace Code
{
    public class SelectionButton : BaseButton
    {
        
    }
}