﻿namespace Code
{
    public interface IState
    {
        
    }
}